from collections import Counter
test_str = input("please enter your input")
res = Counter(test_str)
print(str(res))
