dt = {'Red': 1, 'Green': 2, 'Blue': 3}

for key, value in dt.items():
    print(key, "to", value)
