import math
l = [0, 3, 12, 8, 2]
print(math.prod(l))



