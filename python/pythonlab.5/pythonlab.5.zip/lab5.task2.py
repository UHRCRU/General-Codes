l = [2, 6, 7, 1, 34, 64, 2, 7, 35, 1]
print('Original List:', l)
reversed_list = l[::-1]
print('Updated List:', reversed_list)

