# a = [1, 2, 3, 4, 5, 6, 7, 8]
# b = list[ int(input()) ]
"""
My_list = [*range(1, 9)]
for x in My_list:

    print(x) """
list = [*range(1,9)]
for x in list:
    print(list[:4])
    break

