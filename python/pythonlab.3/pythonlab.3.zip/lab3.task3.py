"""for a in range(1,11):
    print(a, end=" ")
print()
for b in range(2, 11):
   print(b)"""
for i in range (1,11):
    print('\n')
    for j in range(1, 11):
        print (i*j, end='\t')
