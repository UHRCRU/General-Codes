R = [["CA", "NV", "UT"], ["NJ", "NY", "DE"]]

for a in R:
    for b in a:
        print(b)
