x = range(3,20,3)
for n in x:
    print(n, end=" ")
print()

for i in range(1, 20):
   if(i%3==0):
      print(i)
