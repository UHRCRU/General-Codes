while True:
    a = input(str("please enter n or c"))
    if a == str("c") or a == str("n"):
        print("thank you")
        break
    else:
        print("please enter n or c(isnt that complicated)")
        continue
